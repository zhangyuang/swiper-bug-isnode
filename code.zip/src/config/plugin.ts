import { EggPlugin } from 'egg'
export default {
  static: true
} as EggPlugin
