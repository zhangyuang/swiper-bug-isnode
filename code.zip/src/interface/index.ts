export interface IApiService {
  index: () => Promise<any>
}

export * from './detail'
