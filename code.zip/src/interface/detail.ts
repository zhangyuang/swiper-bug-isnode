export interface IApiDetailService {
  index: (id: string) => Promise<any>
}
