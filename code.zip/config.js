module.exports = {
  whiteList: [/antd/]
}
