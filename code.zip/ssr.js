const { asyncWrapper, start } = require('@midwayjs/serverless-fc-starter');
const SimpleLock  = require('@midwayjs/simple-lock').default;
const lock = new SimpleLock();
const layers = [];

try {
  const layer_npm_eggLayer = require('@midwayjs/egg-layer');
  layers.push(layer_npm_eggLayer);
} catch(e) { }


let runtime;
let inited = false;

const initializeMethod = async (initializeContext = {}) => {
  return lock.sureOnce(async () => {
    runtime = await start({
      layers: layers,
      isAppMode: true,
      initContext: initializeContext,
      runtimeConfig: {"service":{"name":"serverless-ssr"},"provider":{"name":"aliyun","initTimeout":10},"custom":{"customDomain":{"domainName":"auto"}},"aggregation":{"ssr":{"deployOrigin":false,"functionsPattern":["*"],"handler":"ssr.handler","_isAggregation":true,"events":[{"http":{"method":"any","path":"/*"}}],"_handlers":[],"_allAggred":[]}},"package":{"include":["build","dist"],"exclude":["package-lock.json"],"artifact":"code.zip"},"deployType":"egg","functions":{"ssr":{"deployOrigin":false,"functionsPattern":["*"],"handler":"ssr.handler","_isAggregation":true,"events":[{"http":{"method":"any","path":"/*"}}],"_handlers":[],"_allAggred":[]}},"globalDependencies":{"@midwayjs/simple-lock":"*","@midwayjs/serverless-fc-starter":"*"},"layers":{"eggLayer":{"path":"npm:@midwayjs/egg-layer"}}},
    });
  }, 'APP_START_LOCK_KEY');
};

exports.initializer = asyncWrapper(async (...args) => {
  if (!inited) {
    inited = true;
    await initializeMethod();
  }
});


  exports.handler = asyncWrapper(async (...args) => {
    if (!inited) {
      await initializeMethod();
    }

    return runtime.asyncEvent()(...args);
  });

